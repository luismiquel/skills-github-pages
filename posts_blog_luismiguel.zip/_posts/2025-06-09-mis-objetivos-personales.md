---
title: "Mis objetivos personales"
date: 2025-06-09
---

Este blog lo usaré para compartir ideas, avances y reflexiones sobre cómo mejorar cada día.  
Mis tres pilares son: constancia, creatividad y actitud positiva.  
Esto es solo el comienzo.
