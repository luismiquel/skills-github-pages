---
title: "Ideas de proyectos para mi sitio"
date: 2025-06-10
---

Estoy pensando en añadir un portafolio, una página de contacto y una sección para mostrar mis progresos.  
GitHub Pages me da el control total sin depender de nadie.  
Pronto vendrán más ideas.
