---
title: "Cómo empecé en GitHub Pages"
date: 2025-06-08
---

Hoy terminé mi primer curso de GitHub Pages.  
No tenía ni idea de que se podía hacer una web así de fácil desde un repositorio.  
¡Estoy listo para seguir construyendo y personalizando mi sitio!
